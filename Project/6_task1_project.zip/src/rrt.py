# -*- coding: utf-8 -*-
import random
import math

class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None


class RRT:
    def __init__(self):
        self.x_min = -4500
        self.x_max = 4500
        self.y_min = -3000
        self.y_max = 3000
        self.robot_radius = 200
        self.avoid_dist = 200

        self.vision = None
        self.start = Node(0, 0)
        self.end = Node(0, 0)
        self.obstacles = []
        self.max_iter = 800
        self.arrive_threshold = 50


    def plan(self, vision, start_x, start_y, end_x, end_y):
        self.vision = vision
        self.set_obstacle(self.vision)

        self.start.x = start_x
        self.start.y = start_y
        self.end.x = end_x
        self.end.y = end_y

        nodes = [self.start]
        for i in range(self.max_iter):
            rand_node = self.sample()

            nearest_node = self.nearest(nodes, rand_node)
            new_node = self.steer(nearest_node, rand_node, step_size=400)
            new_node.parent = nearest_node

            if not self.collision(new_node):
                nodes.append(new_node)

                if self.dist_node(new_node, self.end) <= self.arrive_threshold:
                    print("path: ", self.find_path(nodes[-1]))
                    return self.find_path(nodes[-1])

        return None
    

    def set_obstacle(self, vision):
        for robot_blue in vision.blue_robot:
            if robot_blue.visible and robot_blue.id > 0:
                self.obstacles.append([robot_blue.x, robot_blue.y])
        for robot_yellow in vision.yellow_robot:
            if robot_yellow.visible:
                self.obstacles.append([robot_yellow.x, robot_yellow.y])
    

    def sample(self, rate=0.9):
        if random.random() <= rate:
            rand = Node(random.uniform(self.x_min, self.x_max), random.uniform(self.y_min, self.y_max))
        else:
            rand = Node(self.end.x, self.end.y)
        return rand


    def steer(self, start, end, step_size=1):
        dist = self.dist_node(start, end)
        if dist < step_size:
            return end
        else:
            ratio = step_size / dist
            x = start.x + ratio * (end.x - start.x)
            y = start.y + ratio * (end.y - start.y)
            return Node(x, y)

    
    def collision(self, node):
        if not node.parent:
            return True
        else:
            parent = node.parent

        for obstacle in self.obstacles:
            # 计算斜率和截距
            slope = (node.y - parent.y) / (node.x - parent.x)
            intercept = node.y - slope * node.x
            
            # 计算距离
            perpendicular_slope = -1 / slope
            perpendicular_intercept = obstacle[1] - perpendicular_slope * obstacle[0]
            intersection_x = (intercept - perpendicular_intercept) / (perpendicular_slope - slope)
            intersection_y = slope * intersection_x + intercept
            dist = math.sqrt((obstacle[0] - intersection_x)**2 + (obstacle[1] - intersection_y)**2)
            if dist <= self.robot_radius + self.avoid_dist:
                # print("collide")
                return True
            
        return False


    def nearest(self, nodes, target):
        nearest_node = nodes[0]
        nearest_dist = self.dist_node(nearest_node, target)
        for node in nodes:
            dist = self.dist_node(node, target)
            if dist < nearest_dist:
                nearest_node = node
                nearest_dist = dist
        return nearest_node


    def dist_node(self, node1, node2):
        return math.sqrt((node1.x - node2.x)**2 + (node1.y - node2.y)**2)


    def find_path(self, end_node):
        path_nodes = [end_node]
        while path_nodes[-1].parent:
            path_nodes.append(path_nodes[-1].parent)
        return [(node.x, node.y) for node in reversed(path_nodes)]
