import os, sys
import math
sys.path.append(r"sys")
from vision import Vision
from action import Action
from debug import Debugger
from zss_debug_pb2 import Debug_Msgs

import time
import numpy as np

from rt_rrt import RT_RRT
from dwa import DWA


class Robot:
    def __init__(self):
        self.vision = Vision()
        self.action = Action()
        self.debugger = Debugger()
        self.planner = RT_RRT()
    

    def goto(self, goal_x, goal_y):
        global path
        # 1. path planning & velocity planning
        start_time = time.time()
        
        while True:
            start_x, start_y = self.vision.my_robot.x, self.vision.my_robot.y
            # print("start: ", start_x, start_y)

            if((start_x > -999999) and ((start_y > -999999))):
                path, node_list = self.planner.plan(vision=self.vision, start_x=start_x, start_y=start_y, 
                                                    end_x=goal_x, end_y=goal_y)
                if not path == None:
                    break

        dwa = DWA(goal_x, goal_y, vx_max=1200, vx_min = 0)

        step_index = 0              # 记录当前目标点在路径中的索引
        move_jump_flag = False      # 记录是否跳过当前目标点
        while (step_index <= len(path) - 1):
            path_target = path[step_index]
            path_x = path_target[0]
            path_y = path_target[1]
            path_x_list, path_y_list = list(zip(*path))
            dwa.set_target(path_x, path_y)

            move_time = 0
            
            while True:
                # update version information
                dwa.update_vision(self.vision)
        
                if dwa.if_reach_target():
                    # change target point
                    move_jump_flag = False
                    break

                # 如果移动时间过长，且与目标点距离过远，则停止追踪当前目标点并重新选择目标点
                if move_time > self.planner.move_max_time and \
                   move_jump_flag == False and \
                   self.planner.away_from_target(path_x, path_y, self.vision.my_robot.x, self.vision.my_robot.y):
                    next_step_index = self.planner.find_next_target(path, step_index, self.vision.my_robot.x, self.vision.my_robot.y)
                    step_index = next_step_index
                    if next_step_index < len(path) - 1:
                        move_jump_flag = True
                        break
                    else:
                        step_index = len(path) - 1

                # 如果更换了目标点后依然较长时间没有移动到，则继续更换目标点
                if move_time > self.planner.move_max_time_long and move_jump_flag == True:
                    move_jump_flag = False
                
                vx, vw, pred_x, pred_y = dwa.navigate()
         
                # 2. send command
                self.action.sendCommand(vx=vx, vy=0, vw=vw)

                # 3. draw debug msg
                package = Debug_Msgs()
                # self.debugger.draw_all(sample_x, sample_y, road_map, path_x, path_y)
                self.debugger.draw_points(package, path_x_list, path_y_list)
                self.debugger.draw_circle(package, path_x, path_y, radius=100)
                self.debugger.send(package)

                time.sleep(0.01)
                move_time += 0.01
                
            self.action.sendCommand(vx=0, vy=0, vw=0)

            step_index += 1

            self.planner.set_obstacle(self.vision)
            # 找到路径path中被障碍物阻挡的节点
            node_blocked = self.planner.path_blocked(node_list, path, step_index)
            if len(node_blocked) > 0:
                # 更新路径, 将每个被阻挡的节点的cost设为无穷大, 再对其后所有节点的cost进行重新计算
                # 然后依次对其后所有节点进行重连
                # path, node_list = self.planner.update_path(node_list, path, node_blocked)
                while True:
                    start_x_new = self.vision.my_robot.x
                    start_y_new = self.vision.my_robot.x
                    # print("start: ", start_x, start_y)

                    if((start_x > -999999) and ((start_y > -999999))):
                        path, node_list = self.planner.plan(vision=self.vision, start_x=start_x_new, start_y=start_y_new, 
                                                            end_x=goal_x, end_y=goal_y)
                        if not path == None:
                            break

            
        stop_time = time.time()
        
        return stop_time - start_time


if __name__ == '__main__':
    robot = Robot()
    
    while True:    
        robot.goto(-2400, -1500)
        robot.goto(2400, 1500)

        
