from vision import Vision
from math import sqrt, sin, cos, atan2, exp
import numpy as np
import copy

class Range:
    def __init__(self, min: float, max: float):
        self.min = min
        self.max = max
    
class Pos:
    def __init__(self, x: float, y: float, theta: float):
        self.x = x
        self.y = y
        self.theta = theta

class Vel:
    def __init__(self, vx: float, vw: float):
        self.vx = vx
        self.vw = vw

class DWA:
    def __init__(self, final_x, final_y, 
                 vx_min: float=0.0, vx_max: float=500.0, 
                 dx_min: float=-200.0, dx_max: float=200.0, 
                 vw_min: float=-2 * np.pi, vw_max: float=2 * np.pi, 
                 dw_min: float=-1 * np.pi, dw_max: float=1 * np.pi, 
                 dt=0.01, simt=0.3, res=10):
        
        self.obstacles = []  # 障碍物
        # state config
        self.pos = Pos(0.0, 0.0, 0.0)
        self.vel = Vel(0.0, 0.0)
        # range config
        self.vx_range = Range(vx_min, vx_max)
        self.dx_range = Range(dx_min, dx_max)
        self.vw_range = Range(vw_min, vw_max)
        self.dw_range = Range(dw_min, dw_max)
        # target config
        self.target = None
        self.final_x = final_x
        self.final_y = final_y
        self.start = None
        self.reach_dist = 200
        # simulation config
        self.dt = dt
        self.simt = simt
        self.res = res
        
    def update_vision(self, vision: Vision):    # for dynamic case
        # update current position
        self.pos = Pos(vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
        # update obstacles
        self.obstacles = []
        for robot in vision.blue_robot:
            if robot.id != 0:
                self.obstacles.append(Pos(robot.x, robot.y, robot.orientation))
        for robot in vision.yellow_robot:
            self.obstacles.append(Pos(robot.x, robot.y, robot.orientation))
    
    def if_reach_target(self):  
        if self.target.x == self.final_x and self.target.y == self.final_y:
            if sqrt(pow(self.target.x - self.pos.x, 2) + pow(self.target.y - self.pos.y, 2)) < 100:
                return True
        elif sqrt(pow(self.target.x - self.pos.x, 2) + pow(self.target.y - self.pos.y, 2)) < self.reach_dist:
            return True
        else:
            return False
    
    def predict_pos(self, vx_sim, vw_sim):
        pred_pos = copy.copy(self.pos)
        for i in range(int(self.simt / self.dt)):
            pred_pos.x += vx_sim * self.dt * cos(pred_pos.theta)
            pred_pos.y += vx_sim * self.dt * sin(pred_pos.theta)
            pred_pos.theta += vw_sim * self.dt
        return pred_pos
    
    def navigate(self):
        
        vx_min = max(
            self.vx_range.min, 
            self.vel.vx + self.simt * self.dx_range.min,
        )
        vx_max = min(
            self.vx_range.max, 
            self.vel.vx + self.simt * self.dx_range.max,
        )
        vw_min = max(
            self.vw_range.min, 
            self.vel.vw + self.simt * self.dw_range.min,
        )
        vw_max = min(
            self.vw_range.max, 
            self.vel.vw + self.simt * self.dw_range.max,
        )
        
        # start simulation
        final_score = 0
        slct_vx = 0
        slct_vw = 0
        
        for vx_iter in np.linspace(vx_min, vx_max, self.res):
            for vw_iter in np.linspace(vw_min, vw_max, self.res):
             
                pred_pos = self.predict_pos(vx_iter, vw_iter)

                # heading
                heading_score =  1 / (1 + sqrt(pow(pred_pos.x - self.target.x, 2) + pow(pred_pos.y - self.target.y, 2)))
                # heading_score = abs(np.pi + pred_pos.theta - atan2(self.target.y - pred_pos.y, self.target.x - pred_pos.x)) / np.pi 
                
                # dist
                min_dist = 1000000
                for obs in self.obstacles:
                    dist = sqrt(pow(pred_pos.x - obs.x, 2) + pow(pred_pos.y - obs.y, 2))
                    if dist < min_dist:
                        min_dist = dist
                    
                if min_dist < 300:
                    dist_score = min_dist / 300
                    print('dangerous!')
                else:
                    dist_score = 1.0
                
                # velocity
                if sqrt(pow(pred_pos.x - self.target.x, 2) + pow(pred_pos.y - self.target.y, 2)) < 100:
                    vel_score = 1.0 - vx_iter / self.vx_range.max
                else:
                    vel_score = vx_iter / self.vx_range.max
                vel_score = vx_iter / self.vx_range.max
                
                # sum up
                score = 2 * heading_score + 5 * dist_score + 2 * vel_score
                
                if score > final_score:
                    final_score = score
                    slct_vw = vw_iter
                    slct_vx = vx_iter
                    
        self.vel = Vel(slct_vx, slct_vw)
            
        return slct_vx, slct_vw, pred_pos.x, pred_pos.y

    def set_target(self, target_x, target_y):
        self.target = Pos(target_x, target_y, 0.0)