import random
import math

class Node:
    """
    节点类
    """
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.parent = None
        self.kids = []
        self.cost = 0


class RT_RRT:
    """
    RT-RRT算法
    """
    def __init__(self):
        self.x_min = -4500
        self.x_max = 4500
        self.y_min = -3000
        self.y_max = 3000

        self.sample_rate = 0.6         # 随机采样概率
        self.robot_radius = 200        # 机器人半径
        self.avoid_dist = 300          # 路径与机器人间隔距离
        self.step_size = 280           # 走一步的步长
        self.near_radius = 1200        # 查找近邻点X_near的半径
        self.delta = 3000
        self.max_iter = 900            # 最大迭代次数
        self.arrive_threshold = 10     # 到达目标点的判断阈值
        self.min_jump_step = 3         # 跳步的最大步长
        self.max_jump_step = 8         # 跳步的最大步长
        self.move_max_time = 0.02      # DWA单步移动的最大时间
        self.move_max_time_long = 0.4  # DWA跳步后单步移动的最大时间

        self.vision = None
        self.start = Node(0, 0)        # 开始节点
        self.end = Node(0, 0)          # 目标节点
        self.obstacles = []            # 障碍物列表
        

    def plan(self, vision, start_x, start_y, end_x, end_y):
        """
        RRT* 路径规划
        """
        self.vision = None
        self.start = Node(0, 0)        # 开始节点
        self.end = Node(0, 0)          # 目标节点

        # 根据vision设置障碍物
        self.vision = vision
        self.set_obstacle(self.vision)

        self.start.x = start_x
        self.start.y = start_y
        self.end.x = end_x
        self.end.y = end_y
        node_list = [self.start]
        node_end_list = []

        for i in range(self.max_iter):
            # 在可行空间中随机采样
            node_rand = self.sample()
            # 找到树中离采样点最近的树节点
            node_nearest = self.nearest(node_list, node_rand)
            # 根据机器人执行能力生成新节点和新的路径
            node_new = self.steer(node_rand, node_nearest)
            # 如果新节点与其父节点连线无碰, 则加入树中
            if self.collision_free(node_new, node_new.parent):
                # 选择新节点的所有邻节点
                Nodes_near = self.near(node_list, node_new)
                # 对邻节点中的每个节点, 计算以其作为新节点x_new的父节点的cost
                # 找到cost最小的节点，以其作为新节点x_new的父节点
                node_min, cost_min = self.choose_parent(node_new, Nodes_near)
                self.rewire(node_new, node_min, cost_min)

                node_list.append(node_new)

                # 如果新节点到达目标点, 则将node_new加入终点列表
                if self.arrived(node_new.x, node_new.y):
                    node_end = node_new
                    path = self.find_path(node_end)
                    print("path: ", path)
                    return path, node_list

        # # 找到最优路径
        # if(len(node_end_list) > 0):
        #     final_node_end = self.find_best_path(node_end_list)
        #     path = self.find_path(final_node_end)
        #     return path, node_list
        # else:
        return None, node_list
    

    def arrived(self, node_x, node_y):
        """
        判断是否到达目标点
        """
        node = Node(node_x, node_y)
        if self.dist_node(node, self.end) <= self.arrive_threshold:
            return True
        else:
            return False
    

    def set_obstacle(self, vision):
        """
        根据vision设置障碍物
        """
        # 清空障碍物列表
        self.obstacles = []
        # 设置蓝色、黄色机器人障碍物
        for robot_blue in vision.blue_robot:
            if robot_blue.visible and robot_blue.id > 0:
                self.obstacles.append([robot_blue.x, robot_blue.y])
        for robot_yellow in vision.yellow_robot:
            if robot_yellow.visible:
                self.obstacles.append([robot_yellow.x, robot_yellow.y])
    

    def sample(self):
        """
        在可行空间中随机采样: 
        sample_rate概率随机采样, (1-sample_rate)概率直接采样到目标点
        """
        if random.random() <= self.sample_rate:
            node_rand = Node(random.uniform(self.x_min, self.x_max), random.uniform(self.y_min, self.y_max))
        else:
            node_rand = Node(self.end.x, self.end.y)
        return node_rand


    def steer(self, node_rand, node_nearest):
        """
        从x_nearest出发, 向x_rand方向前进step_size, 生成x_new
        """
        dist = self.dist_node(node_nearest, node_rand)
        if dist <= self.step_size:
            return node_rand
        else:
            node_new_x = node_nearest.x + (self.step_size / dist) * (node_rand.x - node_nearest.x)
            node_new_y = node_nearest.y + (self.step_size / dist) * (node_rand.y - node_nearest.y)
            node_new = Node(node_new_x, node_new_y)
            node_new.parent = node_nearest
            node_nearest.kids.append(node_new)
            return node_new


    def node_obstacle_free(self, node):
        """
        检测node是否与障碍物发生碰撞, 若发生碰撞, 返回False
        """
        for obstacle in self.obstacles:
            node_obstacle = Node(obstacle[0], obstacle[1])
            dist = self.dist_node(node, node_obstacle)
            if dist <= self.robot_radius:
                return False
        return True

    
    def collision_free(self, node_1, node_2):
        """
        检测node_1和node_2的连线与障碍物的距离是否小于阈值, 
        若小于, 则发生碰撞, 返回False
        """
        if not node_2:
            return False

        for obstacle in self.obstacles:
            # 计算斜率和截距
            k = (node_2.y - node_1.y) / (node_2.x - node_1.x)
            b = node_1.y - k * node_1.x
            
            # 计算距离
            dist = abs(obstacle[1] - k * obstacle[0] - b) / math.sqrt(1 + k ** 2)
            # 计算垂足
            x0 = (obstacle[0] + k * obstacle[1] - k * b) / (1 + k ** 2)
            y0 = k * x0 + b
            in_two_flag = ((min(node_1.x, node_2.x) - 100) <= x0 and x0 <= (max(node_1.x, node_2.x) + 100) and \
                           (min(node_1.y, node_2.y) - 100) <= y0 and y0 <= (max(node_1.y, node_2.y) + 100))
            # 如果垂足在两点间且距离小于阈值, 则碰撞
            if in_two_flag and (dist <= self.robot_radius):
                # print("collide")
                # print("obs: ", len(self.obstacles), self.obstacles)
                return False

        return True


    def nearest(self, node_list, node_rand):
        """
        找到树中离采样点x_rand近的树节点
        """
        node_nearest = node_list[0]
        nearest_dist = self.dist_node(node_nearest, node_rand)
        for node in node_list:
            dist = self.dist_node(node, node_rand)
            if dist < nearest_dist:
                node_nearest = node
                nearest_dist = dist
        return node_nearest
    
    
    def near(self, node_list, node_new):
        """
        选择x_new的邻域内所有节点
        """
        Nodes_near = []
        for node in node_list:
            if self.dist_node(node, node_new) <= self.near_radius:
                Nodes_near.append(node)
        return Nodes_near
    

    def dist_node(self, node_1, node_2):
        """
        计算两个点间的欧氏距离
        """
        dist = math.sqrt((node_1.x - node_2.x)**2 + (node_1.y - node_2.y)**2)
        return dist


    def choose_parent(self, node_new, Nodes_near):
        """
        对邻节点中的每个节点, 计算以其作为新节点x_new的父节点的cost, 
        找到cost最小的节点, 以其作为新节点x_new的父节点
        """
        node_min = node_new.parent
        cost_min = node_new.cost

        for node_near in Nodes_near:
            cost = node_near.cost + self.dist_node(node_near, node_new)
            if cost < cost_min and self.collision_free(node_near, node_new):
                node_min = node_near
                cost_min = cost
        
        return node_min, cost_min


    def rewire(self, node_new, node_new_parent, cost_new):
        """
        对树进行重连, 将cost最小的节点作为新节点的父节点
        """
        node_new.parent = node_new_parent
        node_new_parent.kids.append(node_new)
        node_new.cost = cost_new


    def find_path(self, node_end):
        """
        从最后一个节点开始回溯路径
        """
        path = [node_end]
        while path[-1].parent:
            path.append(path[-1].parent)
        
        path = reversed(path)
        path = [(node.x, node.y) for node in path]
        
        return path
    

    def find_best_path(self, node_end_list):
        """
        找到终点节点列表中cost最小的节点
        """
        node_end = node_end_list[0]
        for node in node_end_list:
            if node.cost < node_end.cost:
                node_end = node
        return node_end
    

    def away_from_target(self, path_x, path_y, target_x, target_y):
        """
        判断是否离目标点太远
        """
        dist = math.sqrt((path_x - target_x)**2 + (path_y - target_y)**2)
        if dist > (self.robot_radius):
            return True
        else:
            return False


    def find_next_target(self, path, step_index, robot_x, robot_y):
        """
        找到下一个目标点
        """
        dist_min = float('inf')
        next_step_index = step_index + self.min_jump_step
        max_step_index = min(step_index + self.max_jump_step, len(path) - 1)

        for i in range(step_index + 1, max_step_index + 1):
            node_1 = Node(robot_x, robot_y)
            node_2 = Node(path[i][0], path[i][1])
            dist = self.dist_node(node_1, node_2)
            if dist < dist_min:
                dist_min = dist
                next_step_index = i

        return next_step_index
    

    def get_node_index(self, node_list, node_x, node_y):
        """
        获取node在node_list中的索引
        """
        for i in range(len(node_list)):
            if node_list[i].x == node_x and node_list[i].y == node_y:
                return i
        return None


    def path_blocked(self, node_list, path, step_index):
        """
        检查当前路径path第step_index步后的路径是否受到新障碍物的阻挡
        """
        node_blocked = []
        max_step_index = max(step_index, 1)

        for i in range(max_step_index, len(path)):
            node_index = self.get_node_index(node_list, path[i][0], path[i][1])
            node = node_list[node_index]
            if not self.collision_free(node, node.parent):
                node_blocked.append(node)
        
        return node_blocked
    

    def update_path(self, node_list, path, node_blocked):
        """
        更新路径, 将每个被阻挡的节点的cost设为无穷大, 再对其后所有节点的cost进行重新计算,
        然后依次对其后所有节点进行重连
        """
        visited_nodes = []
        # 将每个被阻挡的节点的cost设为无穷大
        for node in node_blocked:
            node.cost = float("inf")
            visited_nodes.append(node)

        # visited_nodes = [self.start]
        # 迭代重新计算所有节点的cost
        while len(visited_nodes) > 0:
            node = visited_nodes.pop()
            node.cost = float("inf")
            # if node.parent:
            #     node.cost = node.parent.cost + self.dist_node(node, node.parent)
            # else:
            #     node.cost = 0
            if len(node.kids) > 0:
                for node_kid in node.kids:
                    if node_kid not in visited_nodes:
                        visited_nodes.append(node_kid)

        visited_nodes = []
        # 迭代重连所有受影响节点后面的节点
        for node in node_blocked:
            visited_nodes.append(node)

        while len(visited_nodes) > 0:
            node = visited_nodes.pop()
            
            # 选择新节点的所有邻节点
            Nodes_near = self.near(node_list, node)
            # 对邻节点中的每个节点, 计算以其作为新节点x_new的父节点的cost
            # 找到cost最小的节点，以其作为新节点x_new的父节点
            node_min, cost_min = self.choose_parent(node, Nodes_near)
            self.rewire(node, node_min, cost_min)

            # 如果新节点到达目标点, 则结束迭代, 返回路径
            if self.arrived(node.x, node.y):
                node_end = node
                path = self.find_path(node_end)
                print("path: ", path)

                return path, node_list

            if len(node.kids) > 0:
                for node_kid in node.kids:
                    if node_kid not in visited_nodes:
                        visited_nodes.append(node_kid)   

        return path, node_list