import os, sys
import math
import argparse
sys.path.append(r"sys")
sys.path.append(r"src")
from vision import Vision
from action import Action
from debug import Debugger
from zss_debug_pb2 import Debug_Msgs

import time
import numpy as np

from evaluator import Evaluator
from rrt_star import RRT_star
from dwa import DWA


# parser = argparse.ArgumentParser(description='Robot Navigation Expirement')
# parser.add_argument('--task', type=int, default=1, help='task to run')

# args = parser.parse_args()
# task = args.task


class Robot:
    def __init__(self):
        self.vision = Vision()
        self.action = Action()
        self.debugger = Debugger()
        # self.planner = PRM(N_SAMPLE=1000)
        self.planner = RRT_star()


    def path_planning(self, goal_x, goal_y):
        start_time = time.time()
        
        while True:
            start_x, start_y = self.vision.my_robot.x, self.vision.my_robot.y
            # print("start: ", start_x, start_y)

            if((start_x > -999999) and ((start_y > -999999))):
                path = self.planner.plan(vision=self.vision, start_x=start_x, start_y=start_y, 
                                        end_x=goal_x, end_y=goal_y, method='RRT*')
                if not path == None:
                    break

        etime1 = time.time()
        # print("path planning time: ", etime1 - start_time)

        # 3. draw debug msg
        package = Debug_Msgs()
        # self.debugger.draw_all(sample_x, sample_y, road_map, path_x, path_y)
        path_x_list, path_y_list = list(zip(*path))
        self.debugger.draw_points(package, path_x_list, path_y_list)
        self.debugger.send(package)
        return path
    

    def goto(self, goal_x, goal_y):
        # 1. path planning & velocity planning
        start_time = time.time()
        
        while True:
            start_x, start_y = self.vision.my_robot.x, self.vision.my_robot.y
            # print("start: ", start_x, start_y)

            if((start_x > -999999) and ((start_y > -999999))):
                path = self.planner.plan(vision=self.vision, start_x=start_x, start_y=start_y, 
                                        end_x=goal_x, end_y=goal_y, method='RRT*')
                if not path == None:
                    # print("path: ", path)
                    break

        etime1 = time.time()
        print("path planning time: ", etime1 - start_time)

        dwa = DWA(goal_x, goal_y, vx_max=1600)
        #eva = Evaluator()

        # visit target points in correct order
        step_index = 0              # 记录当前目标点在路径中的索引
        move_jump_flag = False      # 记录是否跳过当前目标点
        
        while (step_index <= len(path) - 1):
            path_target = path[step_index]   
            path_x = path_target[0]
            path_y = path_target[1]

            # print("target: ", path_x, path_y)


            path_x_list, path_y_list = list(zip(*path))
            dwa.set_target(path_x, path_y)
            
            move_time = 0
            
            while True:
                # update version information
                dwa.update_vision(self.vision)
                #eva.recording(self.vision)

                if dwa.if_reach_target():
                    # change target point
                    move_jump_flag = False
                    break
                
                # 如果移动时间过长，且与目标点距离过远，则停止追踪当前目标点并重新选择目标点
                if move_time > self.planner.move_max_time and \
                   move_jump_flag == False and \
                   step_index < len(path) - 2 and \
                   self.planner.away_from_target(path_x, path_y, self.vision.my_robot.x, self.vision.my_robot.y):
                    next_step_index = self.planner.find_next_target(path, step_index, self.vision.my_robot.x, self.vision.my_robot.y)
                    step_index = next_step_index
                    # if step_index < len(path) - 1:
                    move_jump_flag = True
                    break

                # 如果更换了目标点后依然较长时间没有移动到，则继续更换目标点
                if move_time > self.planner.move_max_time_long and move_jump_flag == True:
                    move_jump_flag = False

                vx, vw = dwa.navigate()

                vx = self.start_adj(start_x, start_y, path_x, path_y, step_index, vx, vw)

                vx, vw = self.end_adj(step_index, path, vx, vw)

                # 2. send command
                self.action.sendCommand(vx=vx, vy=0, vw=vw)

                # 3. draw debug msg
                package = Debug_Msgs()
                # self.debugger.draw_all(sample_x, sample_y, road_map, path_x, path_y)
                self.debugger.draw_points(package, path_x_list, path_y_list)
                self.debugger.draw_circle(package, path_x, path_y, radius=100)
                self.debugger.send(package)

                time.sleep(0.01)
                move_time += 0.01
                
            self.action.sendCommand(vx=0, vy=0, vw=0)

            if move_jump_flag == False:
                step_index += 1


        stop_time = time.time()
        # time.sleep(0.5)

        #eva.plot_history()
        return stop_time - start_time
    

    def start_adj(self, start_x, start_y, path_x,path_y,step_index, vx, vw):
        # if step_index <= 2:
        #     vx = 0.5 * vx
        # if target_id<3:
        #     vx=target_id*0.1*vx
        if abs(start_x-self.vision.my_robot.x)<150 and abs(start_y-self.vision.my_robot.y)<150:
            vx = 0.36 * vx
        return vx


    def end_adj(self, step_index, path, vx, vw):
        if step_index>=len(path)-3:
            vx = 0.9 * vx
            vw = 0.9 * vw
        return vx, vw


if __name__ == '__main__':
    robot = Robot()

    task = 2

    if task == 1:
        # task1: 路径规划
        while True:
            robot.path_planning(-2400, -1500)
            # time.sleep(3)

    elif task == 2:
        # task2: 轨迹规划
        for i in range(10):    
            robot.goto(-2400, -1500)
            robot.goto(2400, 1500)


        
