from vision import Vision
from action import Action
from debug import Debugger
from matplotlib import pyplot as plt
from zss_debug_pb2 import Debug_Msgs

import time
import numpy as np

class Evaluator:
    def __init__(self):
        self.vision = None

        self.x_rec = np.array([])   # x
        self.theta_rec = np.array([])   # theta
        self.v_rec = np.array([])   # 线速度
        self.w_rec = np.array([])   # 角速度
        self.a_rec = np.array([])   # 线速度加速度
        self.b_rec = np.array([])   # 角速度加速度
        self.t_rec = np.array([])
        
        self.start_time = None
        self.last_update_time = None
        self.current_time = 0
        
        self.time_interval = None
        
        # self.record = True
    
    def recording(self, vision: Vision=None):
        
        self.vision = vision
        
        if self.start_time == None:
            # 初始化
            self.start_time = time.time() 
            self.last_update_time = None
            return
        else:
            self.last_update_time = self.current_time
            self.current_time = time.time() - self.start_time
        
        self.time_interval = self.current_time - self.last_update_time
        
        if len(self.v_rec) > 2 and len(self.w_rec) > 2:
            self.a_rec = np.append(self.a_rec, (self.v_rec[-1] - self.v_rec[-2]) / self.time_interval)
            self.b_rec = np.append(self.b_rec, (self.v_rec[-1] - self.w_rec[-2]) / self.time_interval)
        else:
            self.a_rec = np.append(self.a_rec, 0)
            self.b_rec = np.append(self.b_rec, 0)
            
        if len(self.x_rec) > 2 and len(self.theta_rec) > 2:
            self.v_rec = np.append(self.v_rec, (vision.my_robot.x - self.x_rec[-1]) / self.time_interval)
            self.w_rec = np.append(self.w_rec, (vision.my_robot.orientation - self.theta_rec[-1]) / self.time_interval)
        else:
            self.v_rec = np.append(self.v_rec, 0)
            self.w_rec = np.append(self.w_rec, 0)
                                   
        self.t_rec = np.append(self.t_rec, self.current_time)
        self.x_rec = np.append(self.x_rec, vision.my_robot.x)
        self.theta_rec = np.append(self.theta_rec, vision.my_robot.orientation)
        
    def plot_history(self):
        plt.plot(self.t_rec, self.v_rec, label='v')
        plt.show()